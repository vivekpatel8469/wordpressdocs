jQuery(document).ready(function ($) {
  ajaxCallBack();

  // Bind click event to the "Load More" button
  $(document).on('click', '#load-more-product', function () {
    ajaxCallBack();
  });

  // Handle form submission
  $('#custom-filter-form').on('submit', function (e) {
    e.preventDefault();
    // Ensure pagination is reset on form submission
    $('#load-more-product').attr('data-pages', 1);
    ajaxCallBack();
  });

  // Handle filter reset
  $('#reset-filters').on('click', function () {
    $('#custom-filter-form')[0].reset();
    // Reset pagination and trigger AJAX call
    $('#load-more-product').attr('data-pages', 1);
    ajaxCallBack();
  });

  function ajaxCallBack() {
    var paged = $("#load-more-product").attr('data-pages') || 1;
    var per_page = $("#load-more-product").attr('data-per-page');
    var maxpage = $("#load-more-product").attr('data-maxpage') || 1; // Default maxpage to 1 if undefined
    var min_price = $('#min_price').val();
    var max_price = $('#max_price').val();
    var search = $('#search').val();
    var taxonomy_category = $('input[name="category[]"]:checked').map(function () {
      return $(this).val();
    }).get();
    var taxonomy_brand = $('input[name="brand[]"]:checked').map(function () {
      return $(this).val();
    }).get();
    var taxonomy_color = $('input[name="color[]"]:checked').map(function () {
      return $(this).val();
    }).get();
    var taxonomy_size = $('input[name="size[]"]:checked').map(function () {
      return $(this).val();
    }).get();

    var data = {
      'action': 'custom_filter',
      'search': search,
      'category': taxonomy_category,
      'brand': taxonomy_brand,
      'color': taxonomy_color,
      'size': taxonomy_size,
      'per_page': per_page,
      'maxpage': maxpage,
      'paged': paged,
      'min_price': min_price,
      'max_price': max_price
    };

    $.ajax({
      url: wc_ajax_url.ajax_url,
      type: 'POST',
      dataType: 'json',
      data: data,
      success: function (response) {
        if (response.html) {
          if (paged == 1) {
            $('.products').html(response.html);
          } else {
            $('.products').append(response.html);
          }

          if (paged < response.max_page) {
            if ($('#load-more-product').length > 0) {
              $('#load-more-product')
                .attr('data-pages', parseInt(paged) + 1)
                .attr('data-maxpage', response.max_page)
                .attr('data-per-page', per_page)
                .show();
            } else {
              $('.products').after(response.loadMore);
            }
          } else {
            $('#load-more-product').remove();
          }
        } else {
          $('.products').html('<p>No products found.</p>');
        }
      },
      error: function (xhr, status, error) {
        console.error("AJAX Error:", status, error);
      }
    });
  }
});
