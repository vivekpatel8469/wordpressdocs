<?php

class WooCommerce_Remove_Page_Functions
{

    public function __construct()
    {
        // Hook into the 'wp' action to remove default WooCommerce elements
        add_action('wp', array($this, 'remove_woocommerce_elements'));
    }

    public function remove_woocommerce_elements()
    {
        // Remove default sorting dropdown
        remove_action('woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30);

        // Remove pagination
        remove_action('woocommerce_after_shop_loop', 'woocommerce_pagination', 10);

        // Remove "Showing all X results" text
        remove_action('woocommerce_before_shop_loop', 'woocommerce_result_count', 20);
    }
}

// Initialize the class

$remove_page_functions = new WooCommerce_Remove_Page_Functions();
