<?php
class WooCommerce_Product_AJAX_Filter_Front
{
    public function __construct()
    {
        add_shortcode('woocommerce_product_filter', array($this, 'custom_conditional_sidebar'));
    }

    public function custom_conditional_sidebar()
    {
        if (is_shop()) :
            $filter_show_hide = get_option('filter_show_hide', '1');
            $search_by_title = get_option('search_by_title', '1');
            $filter_by_category = get_option('filter_by_category', '1');
            $filter_by_brand = get_option('filter_by_brand', '1');
            $filter_by_color = get_option('filter_by_color', '1');
            $filter_by_size = get_option('filter_by_size', '1');
            $filter_by_price = get_option('filter_by_price', '1');

            // Get Catagories Terms
            $catagoriesTerm = get_terms(array(
                'taxonomy'   => 'product_cat',
                'hide_empty' => false,
            )); ?>

            <?php if ($filter_show_hide == 1) { ?>
                <form id="custom-filter-form">
                    <!-- Search -->
                    <?php if ($search_by_title == 1) { ?>
                        <div class="filter-group">
                            <h4>Search</h4>
                            <input type="text" name="search" id="search" placeholder="Search products...">
                        </div>
                    <?php } ?>

                    <!-- Categories -->
                    <?php if ($filter_by_category == 1) { ?>
                        <div class="filter-group">
                            <h4>Categories</h4>
                            <?php
                            $args = array(
                                'taxonomy'     => 'product_cat',
                                'hide_empty'   => true,
                                'parent'       => 0,
                            );
                            $parent_categories = get_terms($args);
                            foreach ($parent_categories as $parent_category) {
                                echo '<div class="category-group">';
                                echo '<label><input type="checkbox" name="category[]" value="' . $parent_category->term_id . '"> ' . $parent_category->name . '</label><br>';
                                $child_args = array(
                                    'taxonomy'     => 'product_cat',
                                    'hide_empty'   => false,
                                    'parent'       => $parent_category->term_id,
                                );
                                $child_categories = get_terms($child_args);
                                if (!empty($child_categories)) {
                                    echo '<div class="child-categories" style="margin-left: 20px;">';
                                    foreach ($child_categories as $child_category) {
                                        echo '<label><input type="checkbox" name="category[]" value="' . $child_category->term_id . '"> ' . $child_category->name . '</label><br>';
                                    }
                                    echo '</div>';
                                }
                                echo '</div>';
                            } ?>
                        </div>
                    <?php } ?>

                    <!-- Brands -->
                    <?php if ($filter_by_brand == 1) { ?>
                        <div class="filter-group">
                            <h4>Brands</h4>
                            <?php
                            $brands = get_terms('pa_brand', array('hide_empty' => false));
                            foreach ($brands as $brand) {
                                echo '<label><input type="checkbox" name="brand[]" value="' . $brand->term_id . '"> ' . $brand->name . '</label><br>';
                            }
                            ?>
                        </div>
                    <?php } ?>

                    <!-- Colors -->
                    <?php if ($filter_by_color == 1) { ?>
                        <div class="filter-group">
                            <h4>Colors</h4>
                            <?php
                            $colors = get_terms('pa_color', array('hide_empty' => false));
                            foreach ($colors as $color) {
                                echo '<label><input type="checkbox" name="color[]" value="' . $color->term_id . '"> ' . $color->name . '</label><br>';
                            } ?>
                        </div>
                    <?php } ?>

                    <!-- Sizes -->
                    <?php if ($filter_by_size == 1) { ?>
                        <div class="filter-group">
                            <h4>Sizes</h4>
                            <?php
                            $sizes = get_terms('pa_size', array('hide_empty' => false));
                            foreach ($sizes as $size) {
                                echo '<label><input type="checkbox" name="size[]" value="' . $size->term_id . '"> ' . $size->name . '</label><br>';
                            }
                            ?>
                        </div>
                    <?php } ?>

                    <?php if ($filter_by_price ==  1) { ?>
                        <!-- Price Range -->
                        <div class="filter-group">
                            <h4>Price Range</h4>
                            <label for="min_price">Min Price</label>
                            <input type="number" id="min_price" name="min_price" step="0.01" placeholder="0.00">
                            <br>
                            <label for="max_price">Max Price</label>
                            <input type="number" id="max_price" name="max_price" step="0.01" placeholder="0.00">
                        </div>
                    <?php } ?>

                    <div class="buttom">
                        <button class="cust-button" type="submit">Filter</button>
                        <button class="cust-rest-button" type="reset" id="reset-filters">Reset</button>
                    </div>
                </form>
            <?php } ?>
        <?php
        endif; ?>
<?php }
}

// Instantiate the class
$woocommerce_product_ajax_filter = new WooCommerce_Product_AJAX_Filter_Front();
