<?php

/** 
 * @version 1.0.0
 * Includes Functions for admin and front side
 */
class WooAJAXFilter
{
    public function __construct()
    {
        $this->woo_ajax_product_filter_hooks();
    }

    public function woo_ajax_product_filter_hooks()
    {
        add_action('admin_enqueue_scripts', array($this, 'woo_product_labels_admin_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'woo_product_ajax_front_enqueue_scripts'));
    }

    public function woo_product_labels_admin_scripts()
    {
        wp_enqueue_style('woo-ajax-product-filter', WPL_URL . "/admin/assets/css/admin-style.css", array(), WOO_PRODUCT_VERSION);
        wp_enqueue_script('wpl-admin-script', WPL_URL . "admin/assets/js/admin-script.js", array(), WOO_PRODUCT_VERSION);
        wp_enqueue_script('wpl-admin-script', WPL_URL . "https://code.jquery.com/jquery-3.6.0.min.js", array(), WOO_PRODUCT_VERSION);
    }


    public function woo_product_ajax_front_enqueue_scripts()
    {
        wp_enqueue_script('jquery');
        wp_enqueue_style('woo-product-ajax-filter-front-style', WPL_URL . "/front/assets/css/style.css", array(), WOO_PRODUCT_VERSION);
        wp_enqueue_script('woo-product-ajax-filter-front-script', WPL_URL . "/front/assets/js/front.js", array(), WOO_PRODUCT_VERSION);
        wp_localize_script('woo-product-ajax-filter-front-script', 'wc_ajax_url', array('ajax_url' => admin_url('admin-ajax.php'),));
    }
}

$init = new WooAJAXFilter();
