var $ = jQuery;
$(document).ready(function () {
    function openCity(evt, cityName) {
        var $tabcontent = $(".tabcontent");
        var $tablinks = $(".tablinks");
        $tabcontent.hide();
        $tablinks.removeClass("active");
        $("#" + cityName).show();
        $(evt.currentTarget).addClass("active");
        localStorage.setItem("lastOpenTab", cityName);
    }

    function setDefaultTab() {
        var lastOpenTab = localStorage.getItem("lastOpenTab");
        if (lastOpenTab) {
            $("#" + lastOpenTab).show();
            $(".tablinks[data-city='" + lastOpenTab + "']").addClass("active");
        } else {
            $(".tablinks").first().click();
        }
    }

    $(".tablinks").click(function (evt) {
        var cityName = $(this).data("city");
        openCity(evt, cityName);
    });

    setDefaultTab();
});
