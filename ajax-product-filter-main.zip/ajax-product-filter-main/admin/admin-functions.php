<?php
class WooCommerce_Product_AJAX_Filter
{

    // Initialize the plugin
    public function __construct()
    {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'ajax_product_filter_plugin_general_settings'));
        add_action('admin_init', array($this, 'ajax_product_filter_plugin_filter_settings'));
    }
 

    public function add_admin_menu()
    {
        add_menu_page(
            __('Product Filters', 'apf'),
            __('Product Filters', 'apf'),
            'manage_options',
            'product_filter',
            array($this, 'display_filter_seting'),
            'dashicons-welcome-write-blog',
            '58.896427'
        );
    }


    // Display the settings page content
    public function display_filter_seting()
    {
        require_once plugin_dir_path(__DIR__) . 'admin/setings.php';
    }

    public function ajax_product_filter_plugin_general_settings()
    {
        //register our settings
        register_setting('woo-ajax-product-general-seting-group', 'filter_show_hide');
    }
    public function ajax_product_filter_plugin_filter_settings()
    {
        //register our settings
        register_setting('woo-ajax-product-filter-seting-group', 'filter_by_post_per_page');
        register_setting('woo-ajax-product-filter-seting-group', 'search_by_title');
        register_setting('woo-ajax-product-filter-seting-group', 'filter_by_category');
        register_setting('woo-ajax-product-filter-seting-group', 'filter_by_brand');
        register_setting('woo-ajax-product-filter-seting-group', 'filter_by_color');
        register_setting('woo-ajax-product-filter-seting-group', 'filter_by_size');
        register_setting('woo-ajax-product-filter-seting-group', 'filter_by_price');
    }
}

// Instantiate the class
$woocommerce_product_ajax_filter = new WooCommerce_Product_AJAX_Filter();
