<?php

/**
 * Plugin Name:       Advanced Mini Cart
 * Plugin URI:        https://dolphinwebsolution.com/
 * Description:       This is Simple Minicart PLugin For WooCommerce
 * Version:           1.0.0
 * Author:            DWS Vivek Patel
 * Author URI:        https://dolphinwebsolution.com/
 * License URI:       https://dolphinwebsolution.com/
 * Text Domain:       dws-woo-minicart
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
	die;
}

/**
 * Currently plugin version.
 */
define('DWS_WOO_MINICART_VERSION', '1.0.0');

/**
 * Activation Hook.
 */
register_activation_hook(__FILE__, 'dws_minicart_activate');
function dws_minicart_activate()
{
	$default = array(
		'enable-minicart'        => 1,
		'minicart-icon'          => 'wmc-icon-1',
		'minicart-position'      => 'wmc-top-right',
		'wmc-offset'             => 150,
	);
	add_option('dws_minicart_options', $default, '', 'yes');
}

/**
 * Deactivation Hook.
 */
register_deactivation_hook(__FILE__, 'dws_minicart_deactivate');
function dws_minicart_deactivate()
{
}

/**
 * Admin notice if WooCommerce not installed and activated.
 */
function dws_minicart_no_woocommerce()
{ ?>
	<div class="error">
		<p><?php _e('Minicart for WooCommerce Plugin is activated but not effective. It requires WooCommerce in order to work.', 'woo-minicart'); ?></p>
	</div>
<?php
}

/**
 *  Main Class
 */
if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {

	require plugin_dir_path(__FILE__) . 'dws-class-woo-minicart.php';

	new DWS_Minicart_Main_Class();
} else {
	add_action('admin_notices', 'dws_minicart_no_woocommerce');
}

//Add settings link on plugin page
function dws_minicart_settings_link($links)
{
	$settings_link = '<a href="admin.php?page=woo-minicart">Settings</a>';
	array_unshift($links, $settings_link);
	return $links;
}

$plugin = plugin_basename(__FILE__);
add_filter("plugin_action_links_$plugin", 'dws_minicart_settings_link');
