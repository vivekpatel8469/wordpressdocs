<?php

class WC_Sidebar_Widget extends WP_Widget
{
    public function __construct()
    {
        $widget_options = array(
            'classname' => 'wc_sidebar_widget',
            'description' => __('A WooCommerce Sidebar Widget', 'text_domain'),
        );
        parent::__construct(
            'wc_sidebar_widget',
            __('WooCommerce Sidebar Widget', 'text_domain'),
            $widget_options
        );
    }

    public function widget($args, $instance)
    {
        echo $args['before_widget'];

        // Display widget content here
        $this->display_widget_content();

        echo $args['after_widget'];
    }

    private function display_widget_content()
    {
        echo '<div class="wc-sidebar-widget">';
        do_shortcode('[woocommerce_product_filter]');
        echo '</div>';
    }

    public function form($instance)
    {
        $this->render_admin_form($instance);
    }

    private function render_admin_form($instance) {}

    public function update($new_instance, $old_instance)
    {
        return $this->sanitize_instance($new_instance);
    }

    private function sanitize_instance($instance)
    {
        return $instance;
    }
}

function register_wc_sidebar_widget()
{
    register_widget('WC_Sidebar_Widget');
}
add_action('widgets_init', 'register_wc_sidebar_widget');
