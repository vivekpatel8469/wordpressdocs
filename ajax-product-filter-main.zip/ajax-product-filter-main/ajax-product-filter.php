<?php

/**
 * Plugin Name: Ajax Product Filter
 * Plugin URI: #
 * Description: This plugin creates dynamic labels for Woocommerce products.
 * Version: 1.0.0
 * Author: Acquaintsoft
 * Author URI: #
 * Text Domain: ajax-product-filter
 * Requires at least: 6.3
 * Requires PHP: 7.4 
 */
defined('ABSPATH') || exit;

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use Woo Product Labels
 * Rename this for your plugin and update it as you release new versions.
 */
define('WOO_PRODUCT_VERSION', '1.0.0');
define('WPL_DIR', plugin_dir_path(__FILE__));
define('WPL_URL', plugin_dir_url(__FILE__));
 
/**
 * Check for WooCommerce activation
 * version 1.0.0
 */
if (! in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    add_action('admin_notices', 'woo_ajax_product_filter_woocommerce_notice');
    return;
}

/**
 * Activation Hook
 * version 1.0.0
 */
register_activation_hook(__FILE__, 'woo_product_labels_activate');
function woo_product_labels_activate() {}

/**
 * Deactivation Hook
 * version 1.0.0
 **/
register_deactivation_hook(__FILE__, 'woo_product_labels_deactivate');
function woo_product_labels_deactivate() {}

/**
 * Function to display a notice if WooCommerce is not active
 * version 1.0.0
 */
function woo_ajax_product_filter_woocommerce_notice()
{
    $class = 'notice notice-error';
    $message = __('WooCommerce is not activated. This plugin requires WooCommerce to function.', 'text-domain');
    deactivate_plugins('ajax-product-filter/ajax-product-filter.php');
    printf('<div class="%1$s"><p>%2$s</p></div>', $class, $message);
}


require_once plugin_dir_path(__FILE__) . 'admin/admin-functions.php';
require_once plugin_dir_path(__FILE__) . 'includes/enque-functions.php';
require_once plugin_dir_path(__FILE__) . 'front/front-functions.php';
require_once plugin_dir_path(__FILE__) . 'front/product-filter-widget.php';
require_once plugin_dir_path(__FILE__) . 'front/ajax-functions.php';
require_once plugin_dir_path(__FILE__) . 'includes/woo-remove-functions.php';
