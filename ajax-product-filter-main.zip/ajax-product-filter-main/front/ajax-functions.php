<?php
class Custom_Product_Filter
{

    public function __construct()
    {
        add_action('wp_ajax_custom_filter', array($this, 'custom_filter_products'));
        add_action('wp_ajax_nopriv_custom_filter', array($this, 'custom_filter_products'));
    }

    public function custom_filter_products()
    {
        // Get filter data from the request
        $categories = isset($_POST['category']) ? $_POST['category'] : array();
        $brands = isset($_POST['brand']) ? $_POST['brand'] : array();
        $colors = isset($_POST['color']) ? $_POST['color'] : array();
        $sizes = isset($_POST['size']) ? $_POST['size'] : array();
        $min_price = isset($_POST['min_price']) ? floatval($_POST['min_price']) : 0;
        $max_price = isset($_POST['max_price']) ? floatval($_POST['max_price']) : 0;
        $search_term = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
        $per_page = isset($_POST['per_page']) ? intval($_POST['per_page']) : get_option('filter_by_post_per_page');
        $paged = isset($_POST['paged']) ? intval($_POST['paged']) : 1;

        $args = array(
            'post_type'      => 'product',
            'posts_per_page' => $per_page,
            'post_status'    => 'publish',
            's'              => $search_term,
            'meta_query'     => array(),
            'paged'          => $paged,
        );

        $tax_arr = array();

        if (!empty($categories)) {
            $tax_arr[] = array(
                'taxonomy' => 'product_cat',
                'field'    => 'term_id',
                'terms'    => $categories,
                'operator' => 'IN',
            );
        }

        if (!empty($brands)) {
            $tax_arr[] = array(
                'taxonomy' => 'pa_brand',
                'field'    => 'term_id',
                'terms'    => $brands,
                'operator' => 'IN',
            );
        }

        if (!empty($colors)) {
            $tax_arr[] = array(
                'taxonomy' => 'pa_color',
                'field'    => 'term_id',
                'terms'    => $colors,
                'operator' => 'IN',
            );
        }

        if (!empty($sizes)) {
            $tax_arr[] = array(
                'taxonomy' => 'pa_size',
                'field'    => 'term_id',
                'terms'    => $sizes,
                'operator' => 'IN',
            );
        }

        if (!empty($tax_arr)) {
            $args['tax_query'] = $tax_arr;
        }

        if ($min_price > 0 || $max_price > 0) {
            $price_query = array(
                'key'     => '_price',
                'value'   => array($min_price, $max_price),
                'type'    => 'DECIMAL',
                'compare' => 'BETWEEN',
            );
            $args['meta_query'][] = $price_query;
        }

        $query = new WP_Query($args);

        ob_start();

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                wc_get_template_part('content', 'product'); // Or your custom template part
            }
        } else {
            echo '<p>No products found.</p>';
        }
        $product_html = ob_get_clean();

        // Append Load More button
        $loadMoreButton = "";
        if ($query->max_num_pages > $paged) {
            $loadMoreButton = '<button class="load-more-product" id="load-more-product" data-pages="' . ($paged + 1) . '" data-maxpage="' . $query->max_num_pages . '" data-per-page="' . $per_page . '">Load More</button>';
        }

        // Return data in JSON format
        wp_send_json(array(
            'per_page'  => $per_page,
            'max_page'  => $query->max_num_pages,
            'html'      => $product_html,
            'loadMore' => $loadMoreButton,
        ));

        wp_die();
    }
}
new Custom_Product_Filter();
