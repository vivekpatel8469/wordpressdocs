jQuery(document).ready(function () {
	if (jQuery('.wmc-content').hasClass('wmc-products')) {
		jQuery('.wmc-content').css('height', 'auto');
	}

	// jQuery(document).on('touchstart', function (e) {
	// 	var container = jQuery('.wmc-cart-wrapper');

	// 	// if the target of the click isn't the container nor a descendant of the container
	// 	if (!container.is(e.target) && container.has(e.target).length === 0) {
	// 		jQuery('.wmc-content').hide();
	// 	}
	// 	else {
	// 		jQuery('.wmc-content').show();
	// 	}
	// });


	// Check for click on an element with class 'your-trigger-class'
	jQuery('.wmc-cart-wrapper .wmc-cart').on('click', function () {
		jQuery('.wmc-cart-wrapper .wmc-content').toggleClass('active');
	});

	var wmc_custom_icon;

	jQuery('#wk-button').click(function (e) {
		e.preventDefault();
		// If the upload object has already been created, reopen the dialog
		if (wmc_custom_icon) {
			wmc_custom_icon.open();
			return;
		}
		// Extend the wp.media object
		wmc_custom_icon = wp.media.frames.file_frame = wp.media({
			title: 'Select media',
			button: {
				text: 'Select media'
			}, multiple: false
		});

		// When a file is selected, grab the URL and set it as the text field's value
		wmc_custom_icon.on('select', function () {
			var attachment = wmc_custom_icon.state().get('selection').first().toJSON();
			jQuery('#wk-media-url').val(attachment.url);
		});
		// Open the upload dialog
		wmc_custom_icon.open();
	});



});


