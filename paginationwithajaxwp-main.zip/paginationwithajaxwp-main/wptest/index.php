<?php
get_header(); ?>

    <div class="content-area">
            
		<?php the_content(); ?>
            
    </div>

<?php get_footer(); ?>