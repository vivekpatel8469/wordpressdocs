<div class="wrap">
    <h1>Product Ajax Filter</h1>
    <?php settings_errors(); ?>
</div>

<div class="woo-product-seting">
    <div class="tab">
        <button class="tablinks" data-city="General">General</button>
        <button class="tablinks" data-city="Filter">Filter Option</button>
    </div>

    <div id="General" class="tabcontent">
        <form method="post" action="options.php">
            <?php settings_fields('woo-ajax-product-general-seting-group'); ?>
            <?php do_settings_sections('woo-ajax-product-general-seting-group'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Enable/Disable Filter :-</th>
                    <td><input type="checkbox" name="filter_show_hide" value="1" <?php checked(1, get_option('filter_show_hide'), true); ?> /></td>
                </tr>

                <tr valign="top">
                    <th scope="row">Add To Woocomerce Sidebar Widget :-</th>
                    <td>
                        <p>ShortCode :- [woocommerce_product_filter]</p>
                        <p>Widget :- WooCommerce Sidebar Widget</p>
                    </td>
                </tr>

            </table>
            <?php submit_button(); ?>
        </form>
    </div>

    <div id="Filter" class="tabcontent">
        <form method="post" action="options.php">
            <?php settings_fields('woo-ajax-product-filter-seting-group'); ?>
            <?php do_settings_sections('woo-ajax-product-filter-seting-group'); ?>
            <table class="form-table">

                <tr valign="top">
                    <th scope="row">Set Post Per Page :-</th>
                    <td><input type="text" name="filter_by_post_per_page" value="<?php echo esc_attr(get_option('filter_by_post_per_page')); ?>" /></td>
                </tr>

                <tr valign="top">
                    <th scope="row">Filter By Search :-</th>
                    <td><input type="checkbox" name="search_by_title" value="1" <?php checked(1, get_option('search_by_title'), true); ?> /></td>
                </tr>

                <tr valign="top">
                    <th scope="row">Filter By Catagories :-</th>
                    <td><input type="checkbox" name="filter_by_category" value="1" <?php checked(1, get_option('filter_by_category'), true); ?> /></td>
                </tr>

                <tr valign="top">
                    <th scope="row">Filter By Brand :-</th>
                    <td><input type="checkbox" name="filter_by_brand" value="1" <?php checked(1, get_option('filter_by_brand'), true); ?> /></td>
                </tr>

                <tr valign="top">
                    <th scope="row">Filter By Color :-</th>
                    <td><input type="checkbox" name="filter_by_color" value="1" <?php checked(1, get_option('filter_by_color'), true); ?> /></td>
                </tr>

                <tr valign="top">
                    <th scope="row">Filter By Size :-</th>
                    <td><input type="checkbox" name="filter_by_size" value="1" <?php checked(1, get_option('filter_by_size'), true); ?> /></td>
                </tr>

                <tr valign="top">
                    <th scope="row">Filter By Price :-</th>
                    <td><input type="checkbox" name="filter_by_price" value="1" <?php checked(1, get_option('filter_by_price'), true); ?> /></td>
                </tr>

            </table>
            <?php submit_button(); ?>
        </form>
    </div>

</div>